package planekeys.com.dreamhouse;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class DreamHouseApplication {

	public static void main(String[] args) {
		SpringApplication.run(DreamHouseApplication.class, args);
	}

}
